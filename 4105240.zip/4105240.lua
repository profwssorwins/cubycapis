-- Lua provided by RyzenAPI
-- Game: Chakana

-- MAIN APPLICATION
addappid(4105240)

-- MAIN APP DEPOTS / PACKAGES
addappid(4105241,0,"cc32704520a35d579e7d66fa8efc76e2a50e2692db893818dee326fd3cf0d73d")

