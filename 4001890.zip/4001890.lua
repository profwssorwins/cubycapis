-- Lua provided by SkyAPI 
-- Game: How to Fish
addappid(4001890)
addappid(4001891, 1, "b5c8ad37740a8db6d370a6934bf203cfaeb3343003e6277ffc96c63f4df2b7ca")