-- Lua provided by SkyAPI 
-- Game:  Disgaea Mayhem
addappid(4402250, 1, "3c0035ee6bf8f8591d1901d612b921faef63fc609a72ec44b663e2e076f92bb8")
addappid(4402251, 1, "7288b440334cbb767498e62dc86b14892a17e092e9f4626e509f8ac8352e1e78") -- Depot 4402251
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
addappid(4909490)
addappid(4909490, 1, "d1f83c057a5aa626a865489e0fa65d7421c21657026fd468aa4ee3e85efe592c") -- Disgaea Mayhem - ArtBook - Depot 4909490
addappid(4687210) -- Disgaea Mayhem - Fun Weapons Pack
addappid(4687220) -- Disgaea Mayhem - Bonus Story Catastrophe Flan Arc
