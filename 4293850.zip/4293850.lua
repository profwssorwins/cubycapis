-- Lua provided by RyzenAPI
-- Game: Wet Wealth


addappid(4293850) -- Wet Wealth
addappid(4293851, 1, "cf1d398f91159528ba2b18e81d5a2a1610063a14f0e72d9e46e87196ff4fdd4a") -- Depot 4293851
