-- Lua provided by RyzenAPI
-- Game: Foo Is Missing

-- MAIN APPLICATION
addappid(4282170)

-- MAIN APP DEPOTS / PACKAGES
addappid(4282171,0,"69aebd523232b0245f95d4c8bd272e72f02943571f9df2a8b1ed4d8669a1e64e")

