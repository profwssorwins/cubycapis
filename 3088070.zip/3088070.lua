-- Lua provided by RyzenAPI
-- Game: Dark Light: Survivor

-- MAIN APPLICATION
addappid(3088070)

-- MAIN APP DEPOTS / PACKAGES
addappid(3088071,0,"85200b23f21c0ab158ec594e7a12576841e17c51632b8510870a98f38b38ea5c")

