-- Lua provided by RyzenAPI
-- Game: Nothing To Declare

-- MAIN APPLICATION
addappid(3894850) -- Nothing To Declare

-- MAIN APP DEPOTS / PACKAGES
addappid(3894851, 1, "21b002d1c6681f6e2c0eb05344ba13d3c0fddb54e97476318d0820dc84e23198") -- Depot 3894851
addappid(3894852, 1, "6c1fb3c8ec7f13fcf377cb5c2d2c0941eaca44c91447586bd8ce130c6217a78b") -- Depot 3894852
addappid(3894853, 1, "bc9c054629b553dffd5fb17ca45031762693ce7d638c266c3a0ebf7bb1d3d626") -- Depot 3894853

