-- Lua provided by SkyAPI 
-- Game: Halo: Campaign Evolved
addappid(2806050, 1, "ed813e8e735c9a37bc3698804c2f49a73f4cd0ece4535e2b25d9f2f069abfe8e")
addappid(2806051, 1, "400618d2330230a74b26331220f2aed43a92bf65eb23147779810f48f893c6e5")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") 
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(4192200)
addtoken(4192200, "10428145664877263814")
addappid(4192200, 1, "ba2cc915e2f0112e4af89f7147a980880639c08aed6b47703282f5175355a021")
addappid(4073600) -- Foundry Armory Pack - Halo Campaign Evolved
addtoken(4073600, "940170714388947598")
addappid(4485640) -- Halo Campaign Evolved - Premium Edition Upgrade
addtoken(4485640, "10481697796346159886")