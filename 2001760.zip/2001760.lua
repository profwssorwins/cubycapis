-- Lua provided by SkyAPI 
-- Game: Beast of Reincarnation
addappid(2001760)
addappid(2001761, 1, "0d843c3fd4bba4400b829693c665e6394ad8311f3f7f6c0acf31c71eab887c0c")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")