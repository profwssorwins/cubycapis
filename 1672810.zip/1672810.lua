-- Lua provided by SkyAPI 
-- Game: MIO Memories in Orbit
addappid(1672810)
addappid(1672811, 1, "cb73bead2ca7cc72a2ad3fb210203ba2e0732db40cf3700d95b3fc62b825e490")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
