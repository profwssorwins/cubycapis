-- Lua provided by SkyAPI 
-- Game: Gurei
addappid(2191280, 1, "6ff03a929c98ad2496876b4215a7ee7f3adae3fd5818ca6eb190f07c18474d15")
addappid(2191281, 1, "aec0989877300addf49cc6fb8b0798ddf777f9360c7dc9b78c134d3ace85d127")
