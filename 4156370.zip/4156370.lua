-- Lua provided by RyzenAPI
-- Game: Antivirus Girl


addappid(4156370) -- Antivirus Girl
addappid(4156371, 1, "e0a845b988bfb09ee7093b7c3883547d1dbee3c49b57a3c656e485ac8dc5e3a2") -- Depot 4156371
addappid(4156372, 1, "ecbb4e2fca219ecc6a7c2d5b3c1b5740c1b04d60927f28093e486e071fe8f713") -- Depot 4156372
addappid(4156373, 1, "4b72d441b59f017893dbaed24c354a7a37b50cadb59e410860ffb45f5633a1f3") -- Depot 4156373
addappid(4755260)
addappid(4755260, 1, "2345c271c383a9b6dbffbc426d19a0d05e3f926eb187f41265aca25847f64b33") -- Antivirus Girl - Artbook - Depot 4755260
