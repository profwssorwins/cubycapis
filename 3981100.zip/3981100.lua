-- Lua provided by SkyAPI 
-- Game:  Leaf it Alone
addappid(3981100)
addappid(3981101, 1, "56be5b3548cef33e9c53118f311ded8914c2df5ca9430a0264a034dcf185e62e")