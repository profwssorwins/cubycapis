-- Lua provided by SkyAPI 
-- Game: Endacopia
addappid(2684630)
addappid(2684631, 1, "1f7bf3167ca617389ebcd08272a36520465e1b68f1209370d34e4edfb6e4d78d")