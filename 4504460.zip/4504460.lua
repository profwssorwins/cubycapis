-- Lua provided by SkyAPI 
-- Game: Lihiman
addappid(4504460)
addappid(4504461, 1, "b1c736de4b4c520321aabd153ae984e3f5f108e1c62b038713b5909d82a3541f") -- Main