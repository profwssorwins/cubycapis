-- Lua provided by RyzenAPI
-- Game: Aquapark Tycoon

-- MAIN APPLICATION
addappid(2819470)
addappid(4948710)

-- MAIN APP DEPOTS / PACKAGES
addappid(2819471,0,"a38c0eb936bc8daad59b9f70ca0203ed4b5c30ba0750466288574a541d8f67c5")
addappid(2819472,0,"d367f19ab03b2e0f7e3f06064165e3019cd0def122126f73b40e8d6e1349bdc8")

