-- Lua provided by RyzenAPI
-- Game: Stream Avatars

-- MAIN APPLICATION
addappid(665300)
addappid(1346730)

-- MAIN APP DEPOTS / PACKAGES
addappid(665300,0,"c1adf8f82b12c705f3d252b8ce2ce92a12dc3ac81b3229a45fb0817489ca01a5")
addappid(665301,0,"3dcf4555a8f4a9b92f642d2de7e8b125fd06f8455d560852c4bedf7a808dc8c8")

