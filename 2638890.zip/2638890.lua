-- Lua provided by SkyAPI 
-- Game: Onimusha: Way of the Sword
addappid(2638890, 1, "f6dbd80432a5e344e291ffbf52ec20c2b63dcfce030fbd1fb06074dcbb8c64f3") 
addappid(2638891, 1, "65930a28ef13fdb1576424deec5b6f0d117f3690f244de208b9429b5d43439a4")
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
addappid(3932690)
addappid(3932690, 1, "ae623b8dacaeb8d21cb86d567aa86ff6d0d0d82a19a2ba49a9c58507270763da") -- Onimusha WotS - Charm Lion Dog - Depot 3932690
addappid(3935590)
addappid(3935590, 1, "28d2e6001c9eaf98494d9b4b5323962de3f881f781f69797e052911637dc8788") -- Onimusha WotS - Charm White Monkey - Depot 3935590
addappid(3935610)
addappid(3935610, 1, "56f161208df4af3a7e0e7129cff1dee1f38c81b01003d07933c6d4fb218a9adf") -- Onimusha WotS - Charm Oni Lady - Depot 3935610
addappid(3935620)
addappid(3935620, 1, "594fdb52abb5badd92059b30ea8b3b9ac2fa4fcc6e212b84a8c27f34f45ce183") -- Onimusha WotS - Charm Little Dancer - Depot 3935620
addappid(3935630)
addappid(3935630, 1, "747b6ea35a366feb022e5b00f381a6c4ba9f81f329e33ba38a4b91f517178a7d") -- Onimusha WotS - Charm Mentor - Depot 3935630
addappid(3935640)
addappid(3935640, 1, "103212b8b602e4f57ffbbed3c9226324a4b11af450b6460f47e102ebeef255f4") -- Onimusha WotS - Sword Appearance Sealed Curse - Depot 3935640
addappid(3935650)
addappid(3935650, 1, "94b74229ec8e6d08f801029276ea2227551d439fefa1f0960274b8b71bf75d23") -- Onimusha WotS - Sword Appearance White Lion - Depot 3935650
addappid(3935660)
addappid(3935660, 1, "013c1a41111cee6ca8f7a0c988086f862b3af6155acbf5ce1cc75147556be898") -- Onimusha WotS - Sword Appearance Bamboo  Panda - Depot 3935660
addappid(3935670)
addappid(3935670, 1, "d5561c19597467b03d24a2a10640960491668c917c784a502be7368d798a6ca6") -- Onimusha WotS - Sword Appearance Whittled Oar - Depot 3935670
addappid(3935680)
addappid(3935680, 1, "2c7352f8ac7c65b66c089300945fb844986d0972ba720bf5815f0f4dfe437fd1") -- Onimusha WotS - Sword Appearance Raizan - Depot 3935680
addappid(3935710)
addappid(3935710, 1, "c4d54e9c901231dfd6365fd8028113a21ff3b1498ffd3de42b18322657ad163e") -- Onimusha WotS - Sword Appearance Enryuu - Depot 3935710
addappid(3935720)
addappid(3935720, 1, "794c08444318a21509843545dc1563a3f26f31bf365d29491dcbb230a547a610") -- Onimusha WotS - Hellfire Haori - Depot 3935720
addappid(3935730)
addappid(3935730, 1, "c69391d546d04417e6981742ad9aeae6876f5840d6876bfa4188aac85d013234") -- Onimusha WotS - Moonlight Haori - Depot 3935730
addappid(3935740)
addappid(3935740, 1, "4bba0113b4c1ddfc79e5542a436219348d5e10d3f10be5db38b69c0bb2aca625") -- Onimusha WotS - Outfit for Musashi Red Armor - Depot 3935740
addappid(3935760)
addappid(3935760, 1, "463bb96fe33c8de4118c782c9d13955e0e0ce00e7add9efe942ed8233d58b6e0") -- Onimusha WotS - Oni Gauntlet Crimson Lotus - Depot 3935760
addappid(3935770)
addappid(3935770, 1, "8138baf0266d451706216719aa126ce98cc06d32ad32f92753f886b4818d6be6") -- Onimusha WotS - Outfit for Okuni Flower Dance - Depot 3935770
addappid(3935780)
addappid(3935780, 1, "dc474fa75d698f9aada881fb9149175b3e7ff175768390adc147eaf5af3cf8d4") -- Onimusha WotS - Outfit for Okuni Goldfish Dance - Depot 3935780
addappid(3935790)
addappid(3935790, 1, "f80c521e9ef6a61b9d5b12c30487237c5b9d0ba5596e3de9d5b288581d3d81c4") -- Onimusha WotS - Outfit for Okuni Oni Dance - Depot 3935790
addappid(3935820)
addappid(3935820, 1, "3ba87767f5e77a9edc993a83f3a903d0a16e4edbd84e631b5afce889a61df78a") -- Onimusha WotS - Outfit for the Oni Lady Bird Call - Depot 3935820
addappid(3935830)
addappid(3935830, 1, "6cdc9ce5edfe83a926788ee6a3c6630bf45c50cd3c4d327978dc00a26d734ac7") -- Onimusha WotS - Outfit for the Oni Lady Snow Camellia - Depot 3935830
addappid(3935840)
addappid(3935840, 1, "c841af808b50e24f2edde0ebec5b4584ef66fbf02f426018e606187791793c38") -- Onimusha WotS - Outfit for the Oni Lady Elegance - Depot 3935840
addappid(3935880)
addappid(3935880, 1, "9dd129eb50fbfced37a7a85d8af63228eb7e33170d9637ecfb72da05cf087497") -- Onimusha WotS - Materials Pack Red Souls I - Depot 3935880
addappid(3936020)
addappid(3936020, 1, "6d68fa8fc4c1743ef07f48eedaba7e6ab457fbb586dad87a5a93dfeabff8a7cc") -- Onimusha WotS - In-Game Mini Digital Soundtrack - Depot 3936020
addappid(4053020)
addappid(4053020, 1, "0108bc0b7499b66168061f073d9604600f6caf26bb5e361722c9f5216d1a4bd0") -- Onimusha WotS - Cloudbiter Haori - Depot 4053020
