-- Lua provided by SkyAPI
-- Game : Resonance: A Plague Tale Legacy
addappid(2713000) 
addtoken(2713000, "17223300556103744127")
addappid(2713001, 1, "7085af990ca726e5a5e97ac1acd51bf4f32ba387d0f3d5edb114720e52b536b4")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")