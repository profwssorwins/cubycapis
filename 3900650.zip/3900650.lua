-- Lua provided by SkyAPI
-- Game: Spider Roulette
addappid(3900650)
addappid(3900651,0,"dfcff8d2fc50aff51096d46a49e91eb18f6c22ee84d1e00b93f0c6645f6f88a5") -- Main