-- Lua provided by SkyAPI 
-- Game: Dinoblade
addappid(3440070)
addappid(3440071, 1, "1c6bf8d8c26a3ef0f83486db0c29c96a38b9466b90d910f89193b3f70d7f256d") -- Depot 3440071
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)